import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule, FormBuilder , Validators } from '@angular/forms';

@Component({
  selector: 'registration',
  templateUrl: './registration.component.html',
   styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {
  
  employeeForm : FormGroup;

  constructor(private fb : FormBuilder , private router : Router){
  }

  ngOnInit(): void {
    this.employeeForm = this.fb.group({
      name : ['' , Validators.required],
      email : ['' , Validators.required]
    })
  }

  onSubmit() : void{
    console.log(this.employeeForm.value);
    this.router.navigate(['/quiz' , this.employeeForm.get('name').value]);
  }
  
}